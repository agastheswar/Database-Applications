<?php

/**
 * This is a database connection class that uses php's mysqli 
 * object to make connection to mysql database
 * 
 */

require_once 'config/ConfigFile.php';

class DatabaseConnection{
	
	private $connectionString;
	
	/**
	 * default constructor that will connect to database
	 */
 	function __construct() {
 		
 		//connect to mysql with the values that are declared in ConfigFile
      	$this->connectionString = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
      	
      	
      	//check for connection error
		if ($this->connectionString->connect_errno) {
		    echo "Failed to connect to MySQL: (" . $this->connectionString->connect_errno . ") " . $this->connectionString->connect_error;
		}
		
 	}
	
	/**
	 * getter for connectionString
	 */
	public function getConnectionString(){
		return $this->connectionString;
	}
	

	
}


?>