<?php

require_once 'DatabaseConnection.php';


class User implements CRUD{
	
	private $id, $email, $password, $name, $connectionString;	
	
	
	function __construct(){
		
		
	}
	
	
	public function login(){
		
		//sql for the login
		$sql = "";
		
		//query the database
		$result = $this->getConnectionString()->query($sql);
		
	}
	
	
	public function setId($id){
		$this->id = $id;
	}
	
	public function create(){
		
	}
	
	public function read($id){
		
	}
	
	public function update($id){
		
	}
	
	public function destroy($id){
		
	}
}


?>