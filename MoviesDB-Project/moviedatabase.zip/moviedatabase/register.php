<?php
//uncomment below lines for debugging
//ini_set("display_errors", 1);
//error_reporting(E_ALL);

require_once 'classes/DatabaseConnection.php';


//create a database connection
$db = new DatabaseConnection ();


$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$password = $_POST['password'];
$username = $_POST['username'];


$mysqli = $db->getConnectionString();

//start transaction
$mysqli->autocommit(FALSE);


$sql = "INSERT INTO names (firstname,lastname)  
		VALUES ('$fname', '$lname')";



//query the database for movie details
$result = $mysqli->query( $sql );




// make sure result is not an error
if (! $result) {
	echo $mysqli->error;
	echo 1;
	$mysqli->rollback();  // if error, roll back transaction
	exit ();
}


$sqlUser = "INSERT INTO users (user_names_id, username, password, emailid) 
			VALUES ('{$mysqli->insert_id}','$username', '$password', '$email') ";


$result = $mysqli->query($sqlUser);

// make sure result is not an error
if (! $result) {
	echo 2;
	echo $mysqli->error;
	echo 1;
	$mysqli->rollback();  // if error, roll back transaction
	exit ();
}


// no errors so commit transaction
$mysqli->commit();

echo 0;

?>