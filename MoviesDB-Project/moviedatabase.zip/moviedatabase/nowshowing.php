<?php
/**
 * This is for the movies that are now showing
 */


//uncomment below lines for debugging
//ini_set("display_errors", 1);
//error_reporting(E_ALL);

require_once 'classes/DatabaseConnection.php';


//create a database connection
$db = new DatabaseConnection ();

$mysqli = $db->getConnectionString();


//define the query string for movies now showing
$sql = "select movieid, title, imageurl, LEFT(description , 100) AS description   
		from movies 
		where release_date < CURDATE()";



//query the database for movie details
$result = $mysqli->query( $sql );

// make sure result is not an error
if (! $result) {
	echo $mysqli->error;
	echo "problem";
	exit ();
}


/* fetch associative array */
while ( $row = $result->fetch_assoc () ) {
	$movieDetails[] = $row;
}

// free result set from memory
$result->free();

// return the result as a json object
echo json_encode(array("nowShowing" => $movieDetails));
?>