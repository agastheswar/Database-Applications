// javascript file for register
$(document).ready(function() {
	
	
	//hide error message div
	$("#errorMessage").hide();
	
	//hide success message div
	$("#successMessage").hide();
	
	// attach click event to register button
	$("#registerBtn").click(function(e) {
		// do the ajax call 
		doAjaxCall();
		e.preventDefault();
	});

	
	
	function doAjaxCall(){

        $.ajax({
            async: false,
            type: 'POST',
            url: "register.php",
            data: $("#registerForm").serialize(),

            success: function (data) {

            	if(data == 0){
            		  $("#successMessage").html("Your account was registered successfully");
                      $("#successMessage").show();
                      return false;

            	}else{
            		  $("#errorMessage").html("There was a problem registering your account");
                      $("#errorMessage").show();
                      return false;
            	}
            		
            	return false;

            },
            error: function () {
                $("#errorMessage").html("There was a problem registering your account");
                $("#errorMessage").show();
            }
        });
        
        return false;

	}
	
	
});