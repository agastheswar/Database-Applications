/* Javascript file for login */

$(document).ready(function() {
	
	
	//hide error message div
	$("#errorMessage").hide();
	
	//hide success message div
	$("#successMessage").hide();
	
	// attach click event to register button
	$("#loginBtn").click(function(e) {

		//hide error message div
		$("#errorMessage").hide();
		
		//hide success message div
		$("#successMessage").hide();
		
		doAjaxCall();
		return false;
	});

	
	
	function doAjaxCall(){

        $.ajax({
            async: false,
            type: 'POST',
            url: "login.php",
            data: $("#loginForm").serialize(),

            success: function (data) {

            	if(data == 0){
            		  $("#successMessage").html("You have been logged in successfully.");
                      $("#successMessage").show();
                      return false;

            	}else{
            		  $("#errorMessage").html("There was a problem logging into your account.");
                      $("#errorMessage").show();
                      return false;
            	}
            		
            	return false;

            },
            error: function () {
            	$("#errorMessage").html("There was a problem logging into your account.");
                $("#errorMessage").show();
            }
        });
        
        return false;

	}
	
	
});