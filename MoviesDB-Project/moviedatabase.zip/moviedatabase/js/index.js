/**
 * Javascript file for index.html
 * 
 */
 $( document ).ready(function() {




//<div class='row'></div>
//<div class='col-sm-6 col-md-4'><div class='thumbnail'><img data-src='holder.js/300x200' alt='...'><div class='caption'><h3>Thumbnail label</h3><p>...</p><p><a href='#' class='btn btn-primary' role='button'>Button</a> <a href='#' class='btn btn-default' role='button'>Button</a></p></div></div>
  




//do ajax for upcoming movies (Upcoming Releases)
$.ajax({
	        async: false,
	        type: 'GET',
	        url: "upcomingmovies.php",
	        success: function (json) {
	        	
	            var data = jQuery.parseJSON(json).upcomingMovies;
	            
	            var i, count;
	            count = 1;
	            var str = "<div class='row'> ";
	            for(i = 0; i < data.length; i++){
	            	
	            	// for every 4th element close the current row and create a new row
	            	// this will display 3 movies per line
	            	if( (count % 4) == 0){
	            		//close current row
	            		str += "</div>";
	            		//create new row
	            		str += "<div class='row'> ";
	            	}
	            	
	            	str += "<div class='col-sm-5 col-md-4'>" +
	            			"<div class='thumbnail'><img style='width:200px;height:200px;' src='" + data[i].imageurl + "'" +
	            			" alt=''><div class='caption'><h3>"+data[i].title+"</h3>" +
	            			"<p>" + data[i].description + "...</p>" +
	            			"<p><a href='viewmovie.html?id="+ data[i].movieid +"' class='btn btn-primary' role='button'>View Details</a></p></div></div></div>";
	            	
	        
	            	
	            	//iterate count
	            	count++;
	            }

	            //add all the upcoming releases to the gui
	            $("#upcomingReleases").append(str);
	          
	      
	        }
	    });
 
 





//do ajax for current movies (Now Showing)
$.ajax({
	        async: false,
	        type: 'GET',
	        url: "nowshowing.php",
	        success: function (json) {
	        	
	            var data = jQuery.parseJSON(json).nowShowing;
	            
	            var i, count;
	            count = 1;
	            var str = "<div class='row'> ";
	            for(i = 0; i < data.length; i++){
	            	
	            	// for every 4th element close the current row and create a new row
	            	// this will display 3 movies per line
	            	if( (i % 3) == 0){
	            		//alert(count);
	            		//close current row
	            		str += "</div>";
	            		//create new row
	            		str += "<div class='row'> ";
	            	}
	            	
	            	str += "<div class='col-sm-5 col-md-4'>" +
	            			"<div class='thumbnail'><img style='width:200px;height:200px;' src='" + data[i].imageurl + "'" +
	            			" alt=''><div class='caption'><h3>"+data[i].title+"</h3>" +
	            			"<p>" + data[i].description + "...</p>" +
	            			"<p><a href='viewmovie.html?id="+ data[i].movieid +"' class='btn btn-primary' role='button'>View Details</a></p></div></div></div>";
	            	
	        
	            	
	            	//iterate count
	            	count++;
	            }

	            //add all the upcoming releases to the gui
	            $("#nowShowing").append(str);
	          
	      
	        }
	    });
 


 });
