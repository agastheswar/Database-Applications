/* Javascript for viewmovie.html */

 $( document ).ready(function() {
	 
	 
	 
	 function getCookie(c_name)
	 {
		 var c_value = document.cookie;
		 var c_start = c_value.indexOf(" " + c_name + "=");
		 if (c_start == -1)
		   {
		   c_start = c_value.indexOf(c_name + "=");
		   }
		 if (c_start == -1)
		   {
		   c_value = null;
		   }
		 else
		   {
		   c_start = c_value.indexOf("=", c_start) + 1;
		   var c_end = c_value.indexOf(";", c_start);
		   if (c_end == -1)
		   {
		 c_end = c_value.length;
		 }
		 c_value = unescape(c_value.substring(c_start,c_end));
		 }
		 return c_value;
	 }
	 
	 
	 
	 
	 
	 
	 
	 //Hide cast, crew, reviews on page load
	 $("#castDiv").hide();
	 $("#reviewsDiv").hide();
	 $("#crewDiv").hide();
	 $("#awardsDiv").hide();
	 $("#theatersDiv").hide();
	 
	 
	//hide error message div
	$("#errorMessage").hide();
		
	//hide success message div
	$("#successMessage").hide();
	 
	 
	 //disable review form if not logged in
	 if(getCookie("username") == null || getCookie("username") == ""){
		 $("#ratingInput").prop('disabled', true);
		 $("#reviewTA").prop('disabled', true);
		 $("#saveBtn").prop('disabled', true);
	 }
	 

	 //attach onclick for description 
	 $( "#viewDesc" ).click(function() {
		 //hide other divs
		 $("#castDiv").hide();
		 $("#reviewsDiv").hide();
		 $("#crewDiv").hide();
		 $("#awardsDiv").hide();
		 $("#theatersDiv").hide();
		 //show cast div
		 $("#descDiv").show();
		 
		 //add active class to cast LI
		 $("#descLI").addClass( "active" );
		 
		 //remove active from other elements
		 $("#castLI").removeClass("active");
		 $("#reviewsLI").removeClass("active");
		 $("#crewLI").removeClass("active");
		 $("#theatersLI").removeClass("active");
		 $("#awardsLI").removeClass("active");
		});
	 
	 
	 //attach onclick for view cast 
	 $( "#viewCast" ).click(function() {
		 //hide other divs
		 $("#descDiv").hide();
		 $("#reviewsDiv").hide();
		 $("#crewDiv").hide();
		 $("#awardsDiv").hide();
		 $("#theatersDiv").hide();
		 //show cast div
		 $("#castDiv").show();
		 
		 //add active class to cast LI
		 $("#castLI").addClass( "active" );
		 
		 //remove active from other elements
		 $("#descLI").removeClass("active");
		 $("#reviewsLI").removeClass("active");
		 $("#crewLI").removeClass("active");
		 $("#theatersLI").removeClass("active");
		 $("#awardsLI").removeClass("active");
		});
	 
	 //attach onclick for crew 
	 $( "#viewCrew" ).click(function() {
		 //hide other divs
		 $("#castDiv").hide();
		 $("#reviewsDiv").hide();
		 $("#descDiv").hide();
		 $("#awardsDiv").hide();
		 $("#theatersDiv").hide();
		 //show cast div
		 $("#crewDiv").show();
		 
		 //add active class to cast LI
		 $("#crewLI").addClass( "active" );
		 
		 //remove active from other elements
		 $("#castLI").removeClass("active");
		 $("#reviewsLI").removeClass("active");
		 $("#descLI").removeClass("active");
		 $("#theatersLI").removeClass("active");
		 $("#awardsLI").removeClass("active");
		});
	 
	 
	 
	 //attach onclick for reviews 
	 $( "#viewReviews" ).click(function() {
		 //hide other divs
		 $("#descDiv").hide();
		 $("#castDiv").hide();
		 $("#crewDiv").hide();
		 $("#theatersDiv").hide();
		 $("#awardsDiv").hide();
		 //show cast div
		 $("#reviewsDiv").show();
		 
		 //add active class to cast LI
		 $("#reviewsLI").addClass( "active" );
		 
		 //remove active from other elements
		 $("#descLI").removeClass("active");
		 $("#castLI").removeClass("active");
		 $("#crewLI").removeClass("active");
		 $("#theatersLI").removeClass("active");
		 $("#awardsLI").removeClass("active");
		 
		});
	 
	 
	 //attach onclick for awards 
	 $( "#viewAwards" ).click(function() {
		 //hide other divs
		 $("#descDiv").hide();
		 $("#castDiv").hide();
		 $("#crewDiv").hide();
		 $("#reviewsDiv").hide();
		 $("#theatersDiv").hide();
		 //show award div
		 $("#awardsDiv").show();
		 
		 //add active class to cast LI
		 $("#awardsLI").addClass( "active" );
		 
		 //remove active from other elements
		 $("#descLI").removeClass("active");
		 $("#castLI").removeClass("active");
		 $("#crewLI").removeClass("active");
		 $("#reviewsLI").removeClass("active");
		 $("#theatersLI").removeClass("active");
		});
	 
	 
	 //attach onclick for theaters 
	 $( "#viewTheaters" ).click(function() {
		 //hide other divs
		 $("#descDiv").hide();
		 $("#castDiv").hide();
		 $("#crewDiv").hide();
		 $("#reviewsDiv").hide();
		 $("#awardsDiv").hide();
		 //show award div
		 $("#theatersDiv").show();
		 
		 //add active class to theaters LI
		 $("#theatersLI").addClass( "active" );
		 
		 //remove active from other elements
		 $("#descLI").removeClass("active");
		 $("#castLI").removeClass("active");
		 $("#crewLI").removeClass("active");
		 $("#reviewsLI").removeClass("active");
		 $("#awardsLI").removeClass("active");
		});
	 
	 function getUrlVars() {
		    var vars = {};
		    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
		        vars[key] = value;
		    });
		    return vars;
		}
		
		//get the search term paramter from url
		var id = getUrlVars()["id"];
	 
		
	 
	 
	//do ajax for movie details
	 $.ajax({
	 	        async: false,
	 	        type: 'GET',
	 	        url: "viewmovie.php?id=" + id,
	 	        success: function (json) {
	 	        	
	 	            var data = jQuery.parseJSON(json).movie;
	 	          
	 	            var castData = jQuery.parseJSON(json).cast;
	 	            
	 	            var reviewData = jQuery.parseJSON(json).reviews;
	 	            
	 	            var crewData = jQuery.parseJSON(json).crewMembers;
	 	            
	 	            var awardsData = jQuery.parseJSON(json).awards;
	 	            
	 	            var theatersData = jQuery.parseJSON(json).theaters;
	 	            
	 	            var i;
	 	            var str = "<div class='row'> ";
	 	         

	 	            //add all the upcoming releases to the gui
	 	            $("#descText").append(data[0].description);
	 	            $("#movieTitleHeading").html(data[0].title);
	 	            $("#releaseDate").html(data[0].release_date);
	 	            $("#movieImg").html("<img src='"+data[0].imageurl+"' >");
	 	            
	 	            $("#trailerContentArea").append("<iframe src='"+data[0].website_url+"'  >");
	 	            $("#duration").html(data[0].duration);
	 	            
	 	            
	 	            /* now show add the cast to the cast table */
	 	            // name, role name, role
	 	            
	 	            var str = "";
	 	            // add each cast result to str
	 	           for(i = 0; i < castData.length; i++){
	 	           
	 	            	str += "<tr><td>" + castData[i].firstname +" " + castData[i].lastname + "</td>";
	 	            	str += "<td>" + castData[i].rolename + "</td>";
	 	            	str += "<td>" + castData[i].role + "</td></tr>";
	 	            	
	 	            }
	 	           
	 	           // add str to the castTable object
	 	           $("#castTable").append(str);
	 	           
	 	           
	 	           
	 	          var j, str;
	 	          str = "";
	 	          
	 	          // add each review to str
	 	          for(j = 0; j < reviewData.length; j++){
	 	        	  str +="<blockquote><p>"+ reviewData[j].review+"</p><small>" + reviewData[j].username + " </small></blockquote>";
	 	          }
	 	          
	 	          // add str to the review section
	 	          $("#reviewsText").html(str);
	 	          
	 	          str = "";
	 	          //add each crew to str
	 	          for(j = 0; j < crewData.length; j++){
	 	        	    str += "<tr><td>" + crewData[j].firstname +  " " + crewData[j].lastname + "</td>";
	 	            	str += "<td>" + crewData[j].jobtitle + "</td>";
	 	            	str += "<td>" + crewData[j].gender + "</td>";
	 	            	str += "<td>" + crewData[j].Date_of_birth + "</td>";
	 	          }
	 	          //attach str to the crew table
	 	          $("#crewTable").append(str);
	 	          
	 	          
	 	          //make sure movie has awards
	 	          if(awardsData != null && awardsData != ""){
		 	          str = "";
		 	          //add each crew to str
		 	          for(j = 0; j < awardsData.length; j++){
		 	        	    str += "<tr><td>" + awardsData[j].type + "</td>";
		 	            	str += "<td>" + awardsData[j].organization + "</td>";
		 	            	str += "<td>" + awardsData[j].title + "</td>";
		 	          }
		 	          
		 	       //attach str to awardsTable
		 	       $("#awardsTable").append(str);
	 	          
	 	          }else{
	 	        	 // let user know that there are no awards for this movie title
	 	        	 $("#awardsTable").html("There are no awards for this movie.");
	 	          }
	 	          
	 	          
	 	          
	 	          
	 	          
	 	          
	 	          //make sure movie is playing in a theater
	 	          if(theatersData != null && awardsData != ""){
	 	        	  str = "";
		 	          
		 	          //add each movie theater to theaters
		 	          for(j = 0; j < theatersData.length; j++){
		 	        	  
		 	        	str += "<div class='panel panel-primary'>";
		 	        	str += "<div class='panel-heading'>";
		 	        	str += " <h3 class='panel-title'>" + theatersData[j].name + " - " + theatersData[j].city + "</h3></div>";
		 	        	str += "<div class='panel-body'>" + theatersData[j].timings + "</div></div>";
		 	        	  
		 	          }
		 	         
		 	          // append all movie theaters and times to theatersDiv
		 	          $("#theatersDiv").append(str);
	 	          }
	 	          else{
	 	        	  //append no theaters found
	 	        	  $("#theatersDiv").append("There was no movies theaters playing this movie found.");
	 	          }
	 	          

	 	        
	 	          
	 	        }
	 
	 
	 });
	 
	 
	 
	// attach click event to save review button
		$("#saveBtn").click(function(e) {
			// do the ajax call 
			saveReview();
			e.preventDefault();
		});

		
		
		function saveReview(){

	        $.ajax({
	            async: false,
	            type: 'POST',
	            url: "addreview.php?movieid="+ id,
	            data: $("#reviewForm").serialize(),

	            success: function (data) {

	            	if(data == 0){
	            		  $("#successMessage").html("Your review was added successfully");
	                      $("#successMessage").show();
	                      return false;

	            	}else{
	            		  $("#errorMessage").html("There was a problem adding your review");
	                      $("#errorMessage").show();
	                      return false;
	            	}
	            		
	            	return false;

	            },
	            error: function () {
	                $("#errorMessage").html("There was a problem registering your account");
	                $("#errorMessage").show();
	            }
	        });
	        
	        return false;

		}
	 
	 
	 
	 
	 
	 
	 
 });