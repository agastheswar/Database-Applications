// Javascript file for navigation bar
 $( document ).ready(function() {

	// attach click event for search button
	$( "#searchBtn" ).click(function(e) {
		e.preventDefault();
		//open search page with search input as get parameter
		window.open("search.html?searchTerm="+ $("#searchInput").val(), "_self");
	});

 
});