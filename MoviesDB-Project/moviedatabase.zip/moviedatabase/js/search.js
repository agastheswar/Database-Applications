// javascript file for search.html
 $( document ).ready(function() {

	function getUrlVars() {
	    var vars = {};
	    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
	        vars[key] = value;
	    });
	    return vars;
	}
	
	//get the search term paramter from url
	var searchTerm = getUrlVars()["searchTerm"];
	
	//attach header to gui
	$("#searchResultsHeader").html("Search results for: "+ searchTerm);
	
	// do ajax call to retrieve JSON of search results
	$.ajax({
	        async: false,
	        type: 'GET',
	        url: "search.php?searchTerm=" + searchTerm,
	        success: function (json) {
	        	
	            var data = jQuery.parseJSON(json).results;
	            
	            var i;
	            var str = "";
	            for(i = 0; i < data.length; i++){
	        
	            	
	            	str += "<div class='list-group'><a href='viewmovie.html?id="+data[i].movieid+"' class='list-group-item'><h4 class='list-group-item-heading'>"+data[i].title+"</h4><p class='list-group-item-text'>" + data[i].description + "...</p></a>";
	            	
	            	
	            }
	            //add all the results to the gui
	            $("#searchResults").append(str);
	          
	      
	        }
	    });
 
 

 });