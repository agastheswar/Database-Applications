<?php
//uncomment below lines for debugging
//ini_set("display_errors", 1);
//error_reporting(E_ALL);

require_once 'classes/DatabaseConnection.php';


//create a database connection
$db = new DatabaseConnection ();


$username = $_POST['username'];
$password = $_POST['password'];

$mysqli = $db->getConnectionString();



$sql = "SELECT userid FROM users WHERE username = '$username' AND password = '$password'";



//query the database for movie details
$result = $mysqli->query( $sql );




// make sure result is not an error
if (! $result) {
	echo $mysqli->error;
	echo -1;
	exit ();
}


// if there is a row returned then user found so set cookies and ech0
if($result->num_rows > 0){
	$row = $result->fetch_row();

	setcookie("userid", $row[0]);
	setcookie("username", $username);
	echo 0;
}else{
	//user not found so send -1
	echo -1;
}



?>