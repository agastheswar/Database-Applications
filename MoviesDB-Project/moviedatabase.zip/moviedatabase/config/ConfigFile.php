<?php

/* Configuration file that sets the database information
 * 
 */


// must edit the below attributes to your database setup configuration
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", "password");
define("DB_NAME", "moviesdb_server");






?>