<?php
//uncomment below lines for debugging
//ini_set("display_errors", 1);
//error_reporting(E_ALL);

require_once 'classes/DatabaseConnection.php';


//create a database connection
$db = new DatabaseConnection ();



$mysqli = $db->getConnectionString();




$sql = "INSERT INTO user_review_rating (userid,movieid,review,rating) 
		VALUES ('{$_COOKIE['userid']}', '{$_GET['movieid']}', '{$_POST['reviewTA']}', '{$_POST['ratingInput']}')";



//query the database for movie details
$result = $mysqli->query( $sql );




// make sure result is not an error
if (! $result) {
	echo $mysqli->error;
	echo 1;
	exit ();
}


// no errors so echo 0
echo 0;

?>