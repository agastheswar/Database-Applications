<?php
//uncomment below lines for debugging
//ini_set("display_errors", 1);
//error_reporting(E_ALL);

require_once 'classes/DatabaseConnection.php';


//create a database connection
$db = new DatabaseConnection ();

$mysqli = $db->getConnectionString();
// get the movie id that is selected
$id = $_GET ['id'];

//define the query string for movie details
$sql = "SELECT m.title, m.website, m.duration, m.language, m.rating, m.description, m.imageurl, m.release_date ,t.website_url FROM movies m, trailer t where m.movieid='$id' AND t.movieid= m.movieid";



//query the database for movie details
$result = $mysqli->query( $sql );

// make sure result is not an error
if (! $result) {
	echo "problem";
	exit ();
}


/* fetch associative array */
while ( $row = $result->fetch_assoc () ) {
	$movieDetails[] = $row;
}

// free result set from memory
$result->free();


$sqlCast = "select c.rolename, c.role, n.firstname,
		 n.lastname, n.middlename, f.gender, f.website, f.social_networking_page,
		 f.Date_of_birth from cast c, names n, filmunit f 
		where c.filmunitid = f.filmunitid and n.nameid= f.name 
		and f.filmunitid IN (select filmunitid from filmunit_movie where movieid='{$id}')";


//query the database for cast details
$result = $mysqli->query( $sqlCast );

// make sure result is not an error
if (! $result) {
	echo "problem";
	exit ();
}


/* fetch associative array */
while ( $row = $result->fetch_assoc () ) {
	$castDetails[] = $row;
}

//free result set from memory
$result->free();

$sqlReview = "select ur.review, u.username from user_review_rating ur, users u where u.userid = ur.userid and movieid= '$id'";

//query the database for cast details
$result = $mysqli->query( $sqlReview );

// make sure result is not an error
if (! $result) {
	echo "problem";
	exit ();
}


/* fetch associative array */
while ( $row = $result->fetch_assoc () ) {
	$reviews[] = $row;
}

$sqlCrew = "select c1.jobtitle, n.firstname, n.lastname, n.middlename, f.gender, f.website, f.social_networking_page, f.Date_of_birth from crew c1, names n, filmunit f where c1.filmunitid= f.filmunitid and n.nameid= f.name and f.filmunitid IN (select filmunitid from filmunit_movie where movieid='$id');";
//query the database for cast details
$result = $mysqli->query( $sqlCrew );

// make sure result is not an error
if (! $result) {
	echo "problem";
	exit ();
}


/* fetch associative array */
while ( $row = $result->fetch_assoc () ) {
	$crew[] = $row;
}

//clear result set
$result->free();


$sqlAwards = "SELECT amfu.type, amfu.year, a.organization,a.title 
				  FROM award_movie_filmunit amfu, awards a 
				  WHERE amfu.movieid = '$id' AND
				  a.awardid = amfu.awardid";

//query the database for cast awards
$result = $mysqli->query( $sqlAwards );

// make sure result is not an error
if (! $result) {
	echo "problem";
	exit ();
}


/* fetch associative array */
while ( $row = $result->fetch_assoc () ) {
	$awards[] = $row;
}

$sqlTheaters = "SELECT tm.timings, t.name, t.city, t.address, t.website 
					FROM theater_movie tm, theater t 
					WHERE tm.movie_id = '$id' AND t.theaterid = tm.theater_id";

//query the database for cast awards
$result = $mysqli->query( $sqlTheaters );

// make sure result is not an error
if (! $result) {
	echo "problem";
	exit ();
}


/* fetch associative array */
while ( $row = $result->fetch_assoc () ) {
	$theaters[] = $row;
}




// return the result as a json object
echo json_encode(array("movie" => $movieDetails, "cast" => $castDetails,
					   "awards" => $awards, "reviews" => $reviews, "crewMembers" => $crew,
					   "theaters" => $theaters));

?>